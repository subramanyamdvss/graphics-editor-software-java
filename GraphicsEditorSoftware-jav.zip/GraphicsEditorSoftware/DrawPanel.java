import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;

/**
 * This class handles mouse events and uses them to draw shapes.
 * It contains a dynamic stack myShapes which is the shapes drawn on the panel.
 * It contains a dynamic stack clearedShape which is the shapes cleared from the panel.
 * It has many variables for the current shape [type, variable to store shape object, color, fill].
 * It contains a JLabel called statusLabel for the mouse coordinates
 * It has mutator methods for currentShapeType, currentShapeColor and currentShapeFilled.
 * It has methods for undoing, redoing and clearing shapes.
 * It has a private inner class MouseHandler which extends MouseAdapter and 
 * handles mouse and mouse motion events used for drawing the current shape.
 */

public class DrawPanel extends JPanel
{
    private LinkedList<MyShape> myShapes; //dynamic stack of shapes
    private LinkedList<MyShape> myeraseShapes;
    private LinkedList<MyShape> clearedShapes; //dynamic stack of cleared shapes from undo
    
    private static final Color BACKGROUND_COLOR = Color.WHITE;
    //current Shape variables
    // private Graphics g1;
    private int currentShapeType; //0 for line, 1 for rect, 2 for oval
    private MyShape currentShapeObject; //stores the current shape object
    private Color currentShapeColor; //current shape color
    private boolean currentShapeFilled;  //determine whether shape is filled or not
    private String currentText;
    private int currentEraserWidth;
    private int currentPencilWidth;
    private BufferedImage grid;
    // private Graphics2D gc;
    // private boolean erase;
    JLabel statusLabel; //status label for mouse coordinates
    // private BufferedImage paintImage = new BufferedImage(1500, 1000, BufferedImage.TYPE_INT_ARGB);
    /**
     * This constructor initializes the dynamic stack for myShapes and clearedShapes.
     * It sets the current shape variables to default values.
     * It initalizes statusLabel from JLabel passed in.
     * Sets up the panel and adds event handling for mouse events.
     */
    private DrawPanel pan = this;
    public DrawPanel(JLabel statusLabel){
        
        myShapes = new LinkedList<MyShape>(); //initialize myShapes dynamic stack
        clearedShapes = new LinkedList<MyShape>(); //initialize clearedShapes dynamic stack
            
        //Initialize current Shape variables
        currentShapeType=0;
        currentShapeObject=null;
        currentShapeColor=Color.BLACK;
        currentShapeFilled=false;
        
        this.statusLabel = statusLabel; //Initialize statusLabel
        
        setLayout(new BorderLayout()); //sets layout to border layout; default is flow layout
        setBackground( Color.WHITE ); //sets background color of panel to white
        add( statusLabel, BorderLayout.SOUTH );  //adds a statuslabel to the south border
        
        // event handling for mouse and mouse motion events
        MouseHandler handler = new MouseHandler();                                    
        addMouseListener( handler );
        addMouseMotionListener( handler ); 
    }
    
    /**
     * Calls the draw method for the existing shapes.
     */
    public void paintComponent( Graphics g )
    {
        super.paintComponent( g );
        // g1 = g;
        // g.drawImage(paintImage, 0, 0, null);
        // draw the shapes
        ArrayList<MyShape> shapeArray=myShapes.getArray();
        for ( int counter=shapeArray.size()-1; counter>=0; counter-- )
            if(shapeArray.get(counter)!=null )
                shapeArray.get(counter).draw(g);
        
        //draws the current Shape Object if it is not null
        if (currentShapeObject!=null ){
            currentShapeObject.draw(g);
        }
    }
    
    //Mutator methods for currentShapeType, currentShapeColor and currentShapeFilled
    
    /**
     * Sets the currentShapeType to type (0 for line, 1 for rect, 2 for oval) passed in.
     */
    public void setCurrentShapeType(int type)
    {
        currentShapeType=type;
    }
    
    /**
     * Sets the currentShapeColor to the Color object passed in.
     * The Color object contains the color for the current shape.
     */
    public void setCurrentShapeColor(Color color)
    {
        currentShapeColor=color;
    }
    
    /**
     * Sets the boolean currentShapeFilled to boolean filled passed in. 
     * If filled=true, current shape is filled. 
     * If filled=false, current shape is not filled.
     */
    public void setCurrentShapeFilled(boolean filled)
    {
        currentShapeFilled=filled;
    }
    
    public void setCurrentText(String str){
        currentText = str;
    }
    
    /**
     * Clear the last shape drawn and calls repaint() to redraw the panel if clearedShapes is not empty
     */
    public void clearLastShape()
    {
        if (! myShapes.isEmpty())
        {   
            // if(myShapes.peek() instanceof EmptyShape) clearedShapes.addFront(myShapes.removeFront());
            

            MyShape tmp ;
            if (myShapes.peek() instanceof MyEraser){
                while((tmp =myShapes.peek()) instanceof MyEraser  ){
                    clearedShapes.addFront(myShapes.removeFront());
                    MyShape tmp2 = myShapes.peek() ;
                    if (tmp2 instanceof MyEraser)
                        if (Math.abs(tmp.getX1() - tmp2.getX2())+Math.abs(tmp.getY1() - tmp2.getY2()) > 60 ){ System.out.println("");break;}
                }
            }
            else if(myShapes.peek() instanceof MyPencil){
                while((tmp =myShapes.peek()) instanceof MyPencil){
                    clearedShapes.addFront(myShapes.removeFront());
                    MyShape tmp2 = myShapes.peek() ;
                    if (tmp2 instanceof MyPencil)
                        if (Math.abs(tmp.getX1() - tmp2.getX2())+Math.abs(tmp.getY1() - tmp2.getY2()) > 6 ){ System.out.println("dvss");break;}
                }
            }
            else {
                clearedShapes.addFront(myShapes.removeFront());                              
            }
            repaint();
        }   
    }
    
    /**
     * Redo the last shape cleared if clearedShapes is not empty
     * It calls repaint() to redraw the panel.
     */
    public void redoLastShape()
    {
        if (! clearedShapes.isEmpty())
        {   
            myShapes.addFront(clearedShapes.removeFront());
            repaint();
        }
    }
    // public void seterase(boolean eraser){
    //     erase = eraser;
    // }
    /**
     * Remove all shapes in current drawing. Also makes clearedShapes empty since you cannot redo after clear.
     * It called repaint() to redraw the panel.
     */
    public void clearDrawing()
    {
        myShapes.makeEmpty();
        clearedShapes.makeEmpty();
        repaint();
    }
    // public BufferedImage getScreenShot(){
    //     BufferedImage bi = new BufferedImage(
    //         pan.getWidth(), pan.getHeight(), BufferedImage.TYPE_INT_RGB);
    //     Graphics2D g = bi.createGraphics();
    //     panel.paint(g);
    //     return bi;
    // }

    public void open() throws IOException{
        JFileChooser c = new JFileChooser();
            // c.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            // c.setAcceptAllFileFilterUsed(false);
            // Demonstrate "Save" dialog:
        int rVal = c.showOpenDialog(null);
        if (rVal == JFileChooser.APPROVE_OPTION) {
                // filename.setText(c.getSelectedFile().getName());
                // dir.setText(c.getCurrentDirectory().toString());
            // ImageIO.write(paintImage, "PNG", new File(c.getCurrentDirectory().toString()+"/"+c.getSelectedFile().getName()));
            // BufferedImage bi = ScreenImage.createImage(this);
            BufferedImage dvss = ImageIO.read(new File(c.getCurrentDirectory().toString()+"/"+c.getSelectedFile().getName()));
            MyBuff dv = new MyBuff(dvss,this);
            myShapes.addFront(dv);
            getGraphics().drawImage(dvss, 0, 0, this);
            // ScreenImage.writeImage(bi,c.getCurrentDirectory().toString()+"/"+c.getSelectedFile().getName() );
        }
            
        if (rVal == JFileChooser.CANCEL_OPTION) {
                
        }
    }
    public void save() throws IOException{
        JFileChooser c = new JFileChooser();
            // c.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            // c.setAcceptAllFileFilterUsed(false);
            // Demonstrate "Save" dialog:
        int rVal = c.showSaveDialog(null);
        if (rVal == JFileChooser.APPROVE_OPTION) {
                // filename.setText(c.getSelectedFile().getName());
                // dir.setText(c.getCurrentDirectory().toString());
            // ImageIO.write(paintImage, "PNG", new File(c.getCurrentDirectory().toString()+"/"+c.getSelectedFile().getName()));
            BufferedImage bi = ScreenImage.createImage(this);
            ScreenImage.writeImage(bi,c.getCurrentDirectory().toString()+"/"+c.getSelectedFile().getName() );
        }
            
        if (rVal == JFileChooser.CANCEL_OPTION) {
                
        }
    }
    /**
     * Private inner class that implements MouseAdapter and does event handling for mouse events.
     */
    private class MouseHandler extends MouseAdapter 
    {
        /**
         * When mouse is pressed draw a shape object based on type, color and filled.
         * X1,Y1 & X2,Y2 coordinate for the drawn shape are both set to the same X & Y mouse position.
         */
        public void mousePressed( MouseEvent event )
        {

            switch (currentShapeType) //0 for line, 1 for rect, 2 for oval
            {
                case 0:
                    currentShapeObject= new MyLine( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), currentShapeColor);
                    break;
                case 1:
                    currentShapeObject= new MyRectangle( event.getX(), event.getY(), 
                                                        event.getX(), event.getY(), currentShapeColor, currentShapeFilled);
                    break;
                case 2:
                    currentShapeObject= new MyOval( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), currentShapeColor, currentShapeFilled);
                    break;
                case 3:
                    currentShapeObject= new MyCircle( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), currentShapeColor, currentShapeFilled);
                    break;
                case 4:
                    currentShapeObject= new MyText( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), currentShapeColor, currentShapeFilled,currentText);
                    break;
                case 5:
                    currentShapeObject= new MyEraser( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), BACKGROUND_COLOR, true,currentEraserWidth);
                    break;
                case 6:

                    currentShapeObject= new MyPencil( event.getX(), event.getY(), 
                                                   event.getX(), event.getY(), currentShapeColor,10);
                    break;
                case 7:
                    currentShapeObject= new MyBucket( event.getX(), event.getY(), 
                                                    currentShapeColor,pan);
                    
            }// end switch case
            repaint();
        } // end method mousePressed
        
        /**
         * When mouse is released set currentShapeObject's x2 & y2 to mouse pos.
         * Then addFront currentShapeObject onto the myShapes dynamic Stack 
         * and set currentShapeObject to null [clearing current shape object since it has been drawn].
         * Lastly, it clears all shape objects in clearedShapes [because you cannot redo after a new drawing]
         * and calls repaint() to redraw panel.
         */
        public void mouseReleased( MouseEvent event )
        {
            //sets currentShapeObject x2 & Y2
            currentShapeObject.setX2(event.getX());
            currentShapeObject.setY2(event.getY());
            myShapes.addFront(currentShapeObject); //addFront currentShapeObject onto myShapes
            currentShapeObject=null; //sets currentShapeObject to null
            clearedShapes.makeEmpty(); //clears clearedShapes
            
            repaint();
            
        } // end method mouseReleased
        
        /**
         * This method gets the mouse pos when it is moving and sets it to statusLabel.
         */
        public void mouseMoved( MouseEvent event )
        {
            statusLabel.setText(String.format("Mouse Coordinates X: %d Y: %d",event.getX(),event.getY()));
        } // end method mouseMoved
        
        /**
         * This method gets the mouse position when it is dragging and sets x2 & y2 of current shape to the mouse pos
         * It also gets the mouse position when it is dragging and sets it to statusLabel
         * Then it calls repaint() to redraw the panel
         */
        public void mouseDragged( MouseEvent event )
        {
            // if(erase == 1){
            //     Color c = gc.getColor();
            //     gc.setColor(BACKGROUND_COLOR);
            //     gc.drawRect(me.getX(), me.getY(), eraserWidth, eraserHeight);
            //     gc.fillRect(me.getX(), me.getY(), eraserWidth, eraserHeight);
            //     gc.setColor(c);
            //     repaint();
            // }
            //sets currentShapeObject x2 & Y2
            if(currentShapeObject instanceof MyEraser){
                myShapes.addFront(currentShapeObject);
                currentShapeObject= new MyEraser( currentShapeObject.getX2(), currentShapeObject.getY2(), 
                                                   event.getX(), event.getY(), BACKGROUND_COLOR, true,40);
            }
            else if(currentShapeObject instanceof MyPencil){
                myShapes.addFront(currentShapeObject);
                currentShapeObject= new MyPencil( currentShapeObject.getX2(), currentShapeObject.getY2(), 
                                                   event.getX(), event.getY(), currentShapeColor,10);

                repaint();
                // System.out.println("dvss");

            }
            
            currentShapeObject.setX2(event.getX());
            currentShapeObject.setY2(event.getY());
            //sets statusLabel to current mouse position
            statusLabel.setText(String.format("Mouse Coordinates X: %d Y: %d",event.getX(),event.getY()));
            
            repaint();
            
        } // end method mouseDragged

            
        
    }// end MouseHandler
    
} // end class DrawPanel