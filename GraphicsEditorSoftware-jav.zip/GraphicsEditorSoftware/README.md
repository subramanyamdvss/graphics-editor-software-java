Graphics Editor Software
===========================


Required
----------
[Java JDK 6](http://www.oracle.com/technetwork/java/javasebusiness/downloads/java-archive-downloads-javase6-419409.htm)

Description
------------
* This program use inheritance and implementation to create a paint program.
* The paint program lets you select a color, a shape (line, rectangle,oval) and whether or not the shape is filled.
* You use the mouse to drag and draw a shape, the shape's coordinate re-adjust automatically with mouse's position as you are dragging. 
* There is an undo button and you can undo as many shapes as you like and a redo button to redo them as well.
* However, if you draw a new shape you can no longer redo.
* There is also a clear button to clear the screen and you cannot undo that.
* There is erase button click and drag to erase
* there is a text box to enter text and PRESS ENTER and select then select text button then click and drag.


