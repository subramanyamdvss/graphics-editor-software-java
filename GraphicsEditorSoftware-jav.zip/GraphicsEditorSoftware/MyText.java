import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JComponent;
import javax.swing.JFrame;

// public class MyText {
//   public static void main(String[] args) {
//     JFrame jf = new JFrame("Demo");
//     Container cp = jf.getContentPane();
//     MyCanvas tl = new MyCanvas();
//     cp.add(tl);
//     jf.setSize(300, 200);
//     jf.setVisible(true);
//   }
// }

// class MyCanvas extends JComponent {
//   public void paint(Graphics g) {
//     Graphics2D g2 = (Graphics2D)g;
//     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
//         RenderingHints.VALUE_ANTIALIAS_ON);
//     Font font = new Font("Serif", Font.PLAIN, 200);
//     g2.setFont(font);

//     g2.drawString("jade", 400, 120); 
//   }
// }



import java.awt.Color;
import java.awt.Graphics;

/**
 * This class inherits from MyBoundedShape and is responsible for drawing a rectangle
 */
public class MyText extends MyBoundedShape
{ 
    /**
     * No parameter constructor which calls the no parameter constructor in MyBoundedShape
     */
    private String str;
    public MyText()
    {
        super();
    }
    
    /** 
     * Overloaded constructor that takes coordinates, color and fill. 
     * It passes them into MyBoundedShape's constructor
     */
    public MyText( int x1, int y1, int x2, int y2, Color color, boolean fill,String str )
    {
        super(x1, y1, x2, y2, color,fill);
        this.str = str;
    } 
    
    /**
     * Overrides the draw method in MyBoundedShape. It sets the gets the color from MyBoundedShape
     * to set the color and the values it needs to draw from MyBoundedShape as well.
     */
    @Override
    public void draw( Graphics g )
    {
        // g.setColor( getColor() ); //sets the color
        
        // g.drawRect( getUpperLeftX(), getUpperLeftY(), getWidth(), getHeight() ); //draws a regular rectangle
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
        Font font = new Font("Serif", Font.PLAIN,(getWidth()+ getHeight())/2 );
        g2.setFont(font);
        g2.setColor(getColor());
        // System.out.println(this.str+"dvss");
        if (str !=null)
        g2.drawString(str,getX1(),getY1()); 
        
    } 
    
}