import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.util.ArrayList;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;

/**
 * This class inherits from MyBoundedShape and is responsible for drawing a oval.
 */
public class MyBuff extends MyBoundedShape
{ 
    /**
     * No parameter constructor which calls the no parameter constructor in MyBoundedShape.
     */
    private BufferedImage img;
    private DrawPanel pan;
    public MyBuff()
    {
        super();
    }
    
    /** 
     * Overloaded constructor that takes coordinates, color and fill. 
     * It passes them into MyBoundedShape's constructor.
     */
    public MyBuff(BufferedImage img,DrawPanel pan )
    {
        super();
        this.img = img;
        this.pan = pan;
    }
    
    /**
     * Overrides the draw method in MyBoundedShape. It sets the gets the color from MyBoundedShape
     * to set the color and the values it needs to draw from MyBoundedShape as well.
     */
    @Override
    public void draw( Graphics g )
    {
        g.drawImage(img, 0, 0, pan);
        
    }
    
} // end class MyOval