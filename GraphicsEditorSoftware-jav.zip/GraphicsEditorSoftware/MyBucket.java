import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.io.File;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
// import java.awt.Color;
import java.awt.Dimension;
// import java.awt.image.BufferedImage;

import javax.swing.*;

/**
 * This class inherits from MyBoundedShape and is responsible for drawing a oval.
 */
public class MyBucket extends MyBoundedShape
{ 
    private Color clrcurr;
    /**
     * No parameter constructor which calls the no parameter constructor in MyBoundedShape.
     */
    private DrawPanel pan;
    public MyBucket()
    {
        super();
    }
    
    /** 
     * Overloaded constructor that takes coordinates, color and fill. 
     * It passes them into MyBoundedShape's constructor.
     */
    public void setColr(int pixel){
        // for (Color clr : colorArray){
        //     if (red==clr.getRed() && green == clr.getGreen() && blue == clr.getBlue()){
        //         clrcurr = clr;
        //     }
        // }
        clrcurr = new Color(pixel);
        return;
    }
    public MyBucket( int x1, int y1, Color color , DrawPanel pan)
    {
        super(x1, y1, 0, 0, color,true);
        this.pan = pan;

    }
    
    
    /**
     * Overrides the draw method in MyBoundedShape. It sets the gets the color from MyBoundedShape
     * to set the color and the values it needs to draw from MyBoundedShape as well.
     */
    public void draw( Graphics g )
    {
        // BufferedImage bi = ScreenImage.createImage(pan);
        // BufferedImage bi = ScreenImage.createImage(pan);
        // ScreenImage.writeImage("/home/surya/Desktop/dvss.png");

        // BufferedImage bi  = (BufferedImage) (pan.createImage(pan.getWidth(), pan.getHeight()));
        BufferedImage bi = getScreenShot(pan);
        try{
            ImageIO.write(bi, "png", new File("/home/surya/Desktop/dvss.png"));
            bi = ImageIO.read(new File("/home/surya/Desktop/dvss.png"));
        }
        catch(IOException io){}
        // String pth = "/tmp/temp.jpg";
        
        // try{ScreenImage.writeImage(bi,pth );}
        // catch(IOException exc){
        //     System.out.println("IOException");
        // }
        //File f = new File("/home/surya/Desktop/GraphicsEditorSoftware/dvss.jpg");
        // Picture pic = new Picture(bi);
        int pixel = bi.getRGB(getX1(), getY1());
        setColr(pixel);
        FloodFill fl = new FloodFill();
        bi = fl.floodfill(getY1(),getX1(),bi,clrcurr,getColor());
        // pic.save("/tmp/temp.jpg");
        // try{bi = ImageIO.read(new File("/home/surya/Desktop/GraphicsEditorSoftware/dvss.jpg"));}
        // catch(IOException exc){
        //     System.out.println("IOException");
        // }
        // try{ScreenImage.writeImage(pic.getImage(),"/home/surya/Desktop/GraphicsEditorSoftware/dvss.jpg" );}
        // catch(IOException exc){
        //     System.out.println("IOException");
        // }
        g.drawImage(bi, 0, 0, pan);

    }

    
} // end class MyOval



