import java.awt.Color;
import java.awt.Graphics;

/**
 * This class inherits from MyBoundedShape and is responsible for drawing a rectangle
 */
public class MyEraser extends MyBoundedShape
{ 
    private int widt = 40;
    /**
     * No parameter constructor which calls the no parameter constructor in MyBoundedShape
     */
    public MyEraser()
    {
        super();
    }
    
    /** 
     * Overloaded constructor that takes coordinates, color and fill. 
     * It passes them into MyBoundedShape's constructor
     */
    public MyEraser( int x1, int y1, int x2, int y2, Color color, boolean fill,int widt )
    {
        super(x1, y1, x2, y2, color,fill);
        this.widt = widt;
    } 
    
    /**
     * Overrides the draw method in MyBoundedShape. It sets the gets the color from MyBoundedShape
     * to set the color and the values it needs to draw from MyBoundedShape as well.
     */
    @Override
    public void draw( Graphics g )
    {
        g.setColor( getColor() ); //sets the color
        if (getFill()) //determines whether fill is true or false
            g.fillRect( getX1(), getY1(), widt, widt ); //draws a filled rectangle
        else
            g.drawRect( getX1(), getY1(), widt, widt  ); //draws a regular rectangle
        
    } 
    
}