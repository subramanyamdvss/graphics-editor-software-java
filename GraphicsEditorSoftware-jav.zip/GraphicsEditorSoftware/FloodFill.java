/* FloodFill.java
 * 
 *
 * Takes an image file as a command-line argument,
 * and flood fills all black regions red.
 *
 * This program is intended primarily to demonstrate an
 * an application of depth-first search.
 *
 * NOTE: You will likely get a StackOverFlowException if you
 *       run this on large images, because Java's default stack
 *       size is quite limited.  The usual workaround for this
 *       is to maintain a stack of pixels that need to be filled.
 *       Instead of recursively calling flood(), you just push
 *       new pixels onto the stack.  flood() runs until the stack is
 *       empty.  Recursion is much more elegant though.
 */
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;
import javax.imageio.ImageIO;
import javax.management.Query;
import java.awt.Color;
import java.awt.image.BufferedImage;

public class FloodFill {
    // getting your java program to pause properly requires
    // some absurd mumbo-jumbo
    private static void sleep(int msec) {
        try {
            Thread.currentThread().sleep(msec);
        } catch (InterruptedException e) { }
    }
    
    // private static void flood(BufferedImage img, boolean[][] mark,
    //                          int row, int col, Color srcColor, Color tgtColor) {
    //     // make sure row and col are inside the image
    //     if (row < 0) return;
    //     if (col < 0) return;
    //     if (row >= img. getHeight()) return;
    //     if (col >= img.getWidth()) return;
        
    //     // make sure this pixel hasn't been visited yet
    //     if (mark[row][col]) return;
        
    //     // make sure this pixel is the right color to fill
    //     if (img.getRGB(col, row)!=(srcColor.getRGB())) return;
        
    //     // fill pixel with target color and mark it as visited
    //     img.setRGB(col, row, tgtColor.getRGB());
    //     mark[row][col] = true;

        
        
    //     // recursively fill surrounding pixels
    //     // (this is equivelant to depth-first search)
    //     flood(img, mark, row - 1, col, srcColor, tgtColor);
    //     flood(img, mark, row + 1, col, srcColor, tgtColor);
    //     flood(img, mark, row, col - 1, srcColor, tgtColor);
    //     flood(img, mark, row, col + 1, srcColor, tgtColor);
    // }
    
    

    // public  BufferedImage floodfill(int row,int col,BufferedImage img,Color clrcurr,Color clrwant) {
         
    //     boolean[][] mark = new boolean[img.getHeight()][img.getWidth()];
        
    // // img.show();
        
    //     flood(img, mark, row, col, clrcurr, clrwant);
    //     return img;
            
        
    // }
    public static BufferedImage floodfill( int row, int col,BufferedImage bimg, Color srcColor, Color tgtColor) {
        // if (args.length != 1) {
        //     System.err.println("ERROR: Pass filename as argument.");
        //     return;
        // }

        // String filename = args[0];
        // String filename =
        // "C:\\Users\\Natthawut\\Desktop\\blob.jpg";
        try {
            

            boolean[][] painted = new boolean[bimg.getHeight()][bimg.getWidth()];
            for(int i = 0;i<bimg.getHeight();++i){
                for(int j =0;j< bimg.getWidth();++j){
                    painted[i][j] = false;
                }
            }
            if (true) {
                if (true) {

                    if ((bimg.getRGB(col, row)==(srcColor.getRGB())) && !painted[row][col]) {

                        Queue<Point> queue = new LinkedList<Point>();
                        Point p1 = new Point(col, row);
                        queue.add(p1);
                        System.out.println(p1.x+"dvss"+(p1.y));
                        int pixelCount = 0;
                        int i = 0;
                        while (!queue.isEmpty()) {
                            Point p = queue.remove();
                            i++;
                            if ((p.x >= 0)
                                    && (p.x < bimg.getWidth() && (p.y >= 0) && (p.y < bimg.getHeight()))) {

                                if (!painted[p.y][p.x]
                                                  && (bimg.getRGB(col, row)==(srcColor.getRGB()))) {
                                    painted[p.y][p.x] = true;
                                    bimg.setRGB(col, row, tgtColor.getRGB());
                                    pixelCount++;
                                    System.out.println((p.x)+"dvss"+(p.y));
                                    queue.add(new Point(p.x + 1, p.y));
                                    queue.add(new Point(p.x - 1, p.y));
                                    queue.add(new Point(p.x, p.y + 1));
                                    queue.add(new Point(p.x, p.y - 1));
                                    System.out.println(queue.size()+"size"+i);
                                }
                            }
                        }
                        System.out.println("Blob detected : " + pixelCount
                                + " pixels");
                    }

                }
            }
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return bimg;
    }
}
