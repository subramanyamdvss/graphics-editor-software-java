import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Color;
import java.io.IOException;


/**
 * Provides the GUI and encapsulates the DrawPanel
 * It creates 3 buttons undo, redo and clear.
 * It creates 2 combobox colors and shapes.
 * It creates 1 checkbox filled to select whether shape is filled or not.
 * Has two private inner classes 
 * One for handling button events
 * Another for handling both combo box events and checkbox events
 */
public class DrawFrame extends JFrame
{
    private JLabel statusLabel; //label display mouse coordinates
    private DrawPanel panel; //draw panel for the shapes
    
    private JButton undo; // button to undo last drawn shape
    private JButton redo; // button to redo an undo
    private JButton clear; // button to clear panel
    private JButton line;
    private JButton rectangle;
    private JButton oval;
    private JButton circle;
    private JButton textopt;
    private JButton save;
    private JButton eraser;
    private JButton pencil;
    private JTextField text;//text field to write text at particular position
    private JButton bucket;
    private JButton open;

    private JComboBox colors; //combobox with color options
    
    //array of strings containing color options for JComboBox colors
    private String colorOptions[]=
    {"Black","Blue","Cyan","Dark Gray","Gray","Green","Light Gray",
        "Magenta","Orange","Pink","Red","White","Yellow"};
    
    //aray of Color objects contating Color constants
    private Color colorArray[]=
    {Color.BLACK , Color.BLUE , Color.CYAN , Color.darkGray , Color.GRAY , 
        Color.GREEN, Color.lightGray , Color.MAGENTA , Color.ORANGE , 
    Color.PINK , Color.RED , Color.WHITE , Color.YELLOW};
    
    // private JComboBox shapes; //combobox with shape options
    
    //array of strings containing shape options for JComboBox shapes
    // private String shapeOptions[]=
    // {"Line","Rectangle","Oval","Circle","Text"};
    
    private JCheckBox filled; //checkbox to select whether shape is filled or not
            
    private JPanel widgetJPanel; //holds the widgets: buttons, comboboxes and checkbox
    private JPanel widgetPadder; //encapsulates widgetJPanel and adds padding around the edges 
    
    /**
     * This constructor sets the name of the JFrame.
     * It also creates a DrawPanel object that extends JPanel for drawing the shapes and contains
     * a statuslabel for mouse position.
     * Initializes widgets for buttons, comboboxes and checkbox
     * It also adds event handlers for the widgets
     */
    public DrawFrame()
    {
        super("Graphics Editor Software"); //sets the name of DrawFrame
        
        JLabel statusLabel = new JLabel( "" ); //create JLabel object to pass into DrawPanel
        
        panel = new DrawPanel(statusLabel); //create draw panel and pass in JLabel
        
        //create buttons
        undo = new JButton( "" );
        undo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/undo.jpeg")));
        redo = new JButton( "" );
        redo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/redo.png")));
        clear = new JButton( "Clear" );
        line = new JButton( "" );
        line.setIcon(new javax.swing.ImageIcon(getClass().getResource("/line.jpg")));
        rectangle = new JButton( "" );
        rectangle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rectangle.jpg")));
        oval = new JButton( "" );
        oval.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ellipse.jpg")));
        circle = new JButton( "" );
        circle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/circle.jpg")));
        textopt = new JButton( "" );
        textopt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/text.png")));
        save = new JButton("Save");
        eraser  = new JButton("Eraser");
        pencil = new JButton("Pencil");
        bucket  = new JButton("Bucket");
        open  = new JButton("Open");
        //create text fields
        text = new JTextField("Enter text here");

        //create comboboxes
        colors = new JComboBox( colorOptions );
        // shapes = new JComboBox( shapeOptions );
        
        //create checkbox
        filled = new JCheckBox( "Filled" );
        
        //JPanel object, widgetJPanel, with grid layout for widgets
        widgetJPanel = new JPanel();
        widgetJPanel.setLayout( new GridLayout( 1, 6, 10, 10 ) ); //sets padding between widgets in gridlayout
        
        //JPanel object, widgetPadder, with flowlayout to encapsulate and pad the widgetJPanel
        widgetPadder = new JPanel();
        widgetPadder.setLayout(new FlowLayout(FlowLayout.LEADING, 20, 5)); //sets padding around the edges
            
        // add widgets to widgetJPanel
        widgetJPanel.add( undo );
        widgetJPanel.add( redo );
        widgetJPanel.add( clear );
        widgetJPanel.add( colors );
        // widgetJPanel.add( shapes );                 
        widgetJPanel.add( filled );
        widgetJPanel.add( line );
        widgetJPanel.add( rectangle );
        widgetJPanel.add( oval );
        widgetJPanel.add( circle );
        widgetJPanel.add( textopt );
        widgetJPanel.add( text );
        widgetJPanel.add( save );
        widgetJPanel.add( open );
        widgetJPanel.add( eraser );
        widgetJPanel.add( pencil );
        widgetJPanel.add(bucket);
        // add widgetJPanel to widgetPadder
        widgetPadder.add( widgetJPanel );
        
        //add widgetPadder and panel to JFrame
        add( widgetPadder, BorderLayout.NORTH);
        add( panel, BorderLayout.CENTER);
        
        // create new ButtonHandler for button event handling
        ButtonHandler buttonHandler = new ButtonHandler();
        undo.addActionListener( buttonHandler );
        redo.addActionListener( buttonHandler );
        clear.addActionListener( buttonHandler );
        line.addActionListener(buttonHandler);
        rectangle.addActionListener(buttonHandler);
        oval.addActionListener(buttonHandler);
        circle.addActionListener(buttonHandler);
        textopt.addActionListener(buttonHandler);
        text.addActionListener(buttonHandler);
        save.addActionListener(buttonHandler);
        eraser.addActionListener(buttonHandler);
        pencil.addActionListener(buttonHandler);
        bucket.addActionListener(buttonHandler);
        open.addActionListener(buttonHandler);
        //create handlers for combobox and checkbox
        ItemListenerHandler handler = new ItemListenerHandler();
        colors.addItemListener( handler );
        // shapes.addItemListener( handler );
        filled.addItemListener( handler );
        

        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        setSize( 1800, 1000 );
        setVisible( true );
        
    } // end DrawFrame constructor
    
    /**
     * private inner class for button event handling
     */
    private class ButtonHandler implements ActionListener
    {
        // handles button events
        public void actionPerformed( ActionEvent event )
        {
            if (event.getSource()==undo){
                panel.clearLastShape();
            }
            else if (event.getSource()==redo){
                panel.redoLastShape();
            }
            else if (event.getSource()==clear){
                panel.clearDrawing();
            }
           
            else if ( event.getSource()==line){
                panel.setCurrentShapeType(getSelectedIndex(line));
            }
            else if ( event.getSource()==rectangle){
                panel.setCurrentShapeType(getSelectedIndex(rectangle));
            }
            else if ( event.getSource()==oval){
                panel.setCurrentShapeType(getSelectedIndex(oval));
            }
            else if ( event.getSource()==circle){
                panel.setCurrentShapeType(getSelectedIndex(circle));
            }
            else if ( event.getSource()==textopt){
                panel.setCurrentShapeType(getSelectedIndex(textopt));
            }
            else if(event.getSource() == save){
                try{panel.save();}
                catch(IOException e){
                    System.out.println("IOException");
                }
            }
            else if (event.getSource()== eraser){
                panel.setCurrentShapeType(getSelectedIndex(eraser));
            }
            else if(event.getSource()== pencil){
                panel.setCurrentShapeType(getSelectedIndex(pencil));
            }
            else if (event.getSource()==bucket){
                panel.setCurrentShapeType(getSelectedIndex(bucket));
            }
            else if(event.getSource()==open){
                try{panel.open();}
                catch(IOException e){
                    System.out.println("IOException");
                }
            }
            // System.out.println(event.getActionCommand());
            panel.setCurrentText(text.getText());
        } // end method actionPerformed
    } // end private inner class ButtonHandler
    

    public int getSelectedIndex(JButton buttn){
        if (buttn == line)
            return 0;
        else if(buttn == rectangle)
            return 1;
        else if(buttn == oval)
            return 2;
        else if(buttn == circle)
            return 3;
        else if(buttn == textopt)
            return 4;
        else if(buttn == eraser)
            return 5;
        else if(buttn == pencil)
            return 6;
        else if(buttn == bucket)
            return 7;
        
        return 0;
    }


    /**
     * private inner class for checkbox and combobox event handling
     */
    private class ItemListenerHandler implements ItemListener
    {
        public void itemStateChanged( ItemEvent event )
        {
            // process filled checkbox events
            if ( event.getSource() == filled )
            {
                boolean checkFill=filled.isSelected() ? true : false; //
                panel.setCurrentShapeFilled(checkFill);
            }
            
            // determine whether combo box selected
            if ( event.getStateChange() == ItemEvent.SELECTED )
            {
                //if event source is combo box colors pass in colorArray at index selected.
                if ( event.getSource() == colors)
                {
                    panel.setCurrentShapeColor
                        (colorArray[colors.getSelectedIndex()]);
                }
                
                //else if event source is combo box shapes pass in index selected
                // else if ( event.getSource() == shapes)
                // {
                //     panel.setCurrentShapeType(getSelectedIndex());
                // }
                 
            }
            
        } // end method itemStateChanged
    }
    
} // end class DrawFrame